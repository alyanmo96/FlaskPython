
import flask
import random


app = flask.Flask("MyApp") # Creating a controller (the object that organizes everything)

users = [
    {"name": "Rick", "age":57},
    {"name": "Morty", "age":14},
]


@app.route("/")
def index():
    return flask.render_template("index.html", title="My awesome app")

@app.route("/cv")
def cv_index():
    return flask.render_template("cv.html", title="My awesome resume")


@app.route('/roll/<int:number>')
def roll(number):
    if number > 100 or number <0:
        return f"{number} exceeds 100!" if number > 100 else f"{number} is less than zero!!!"
    else:
        get_rand_number= random.randint(1, 100)
        if number==get_rand_number:
            return f"Cool the random number is    {get_rand_number} and you insert  " f"{number}   so the both numbers are equals"
        else:
            return f"the random number is    {get_rand_number} and you insert  " f"{number}"
    return number


app.run()
